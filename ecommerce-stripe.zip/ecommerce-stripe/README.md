# E-Commerce React + Node.js + Stripe

This project is a minimal full-stack e-commerce example using:
- React (Vite) frontend
- Node.js + Express backend
- Stripe Checkout for payments

Files included:
- backend/server.js — Express server and Stripe integration
- frontend — Vite + React frontend with product listing and cart
- README and .env examples

See backend/.env.example for required environment variables.

Run locally:
1. Start backend:
   - cd backend
   - copy .env.example to .env and fill keys
   - npm install
   - npm run dev
2. Start frontend:
   - cd frontend
   - npm install
   - npm run dev

Notes:
- Use Stripe CLI to test webhooks: `npx stripe listen --forward-to localhost:4242/webhook`
- Replace in-memory PRODUCTS with a database in production.
