import React from 'react';

export default function ProductList({ products, onAdd }) {
  return (
    <div className="products">
      {products.map(p => (
        <div key={p.id} className="product-card">
          <h3>{p.name}</h3>
          <p>${(p.price_cents / 100).toFixed(2)}</p>
          <button onClick={() => onAdd(p)}>Add to cart</button>
        </div>
      ))}
    </div>
  );
}
