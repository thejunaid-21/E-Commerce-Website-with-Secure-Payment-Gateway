import React, { useMemo } from 'react';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY);

export default function Cart({ cart, setCart, apiBase }) {
  const total = useMemo(() => cart.reduce((s, it) => s + it.price_cents * it.quantity, 0), [cart]);

  const checkout = async () => {
    if (!cart.length) return alert('Cart is empty');
    try {
      const res = await fetch(`${apiBase}/create-checkout-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart.map(c => ({ id: c.id, quantity: c.quantity })),
        }),
      });
      const data = await res.json();
      const { sessionId, error } = data;
      if (error) throw new Error(error.message || 'Checkout error');
      const stripe = await stripePromise;
      const { error: redirectError } = await stripe.redirectToCheckout({ sessionId });
      if (redirectError) console.error(redirectError);
    } catch (err) {
      console.error(err);
      alert('Checkout failed: ' + err.message);
    }
  };

  return (
    <div className="cart">
      <h2>Cart</h2>
      {cart.map(item => (
        <div key={item.id} className="cart-item">
          <span>{item.name} x {item.quantity}</span>
          <span>${((item.price_cents * item.quantity) / 100).toFixed(2)}</span>
        </div>
      ))}
      <hr />
      <div className="cart-total">Total: ${(total/100).toFixed(2)}</div>
      <button onClick={checkout} disabled={!cart.length}>Checkout</button>
    </div>
  );
}
