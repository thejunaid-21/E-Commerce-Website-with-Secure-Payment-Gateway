import React, { useEffect, useState } from 'react';
import ProductList from './components/ProductList';
import Cart from './components/Cart';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4242';

export default function App() {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    fetch(`${API}/products`).then(r => r.json()).then(setProducts);
  }, []);

  const addToCart = (product) => {
    setCart(prev => {
      const found = prev.find(p => p.id === product.id);
      if (found) return prev.map(p => p.id === product.id ? { ...p, quantity: p.quantity + 1 } : p);
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  return (
    <div className="app">
      <h1>Simple Shop</h1>
      <div className="layout">
        <ProductList products={products} onAdd={addToCart} />
        <Cart cart={cart} setCart={setCart} apiBase={API} />
      </div>
    </div>
  );
}
