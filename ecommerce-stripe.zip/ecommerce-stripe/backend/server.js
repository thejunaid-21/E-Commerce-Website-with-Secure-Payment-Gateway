// server.js
import express from 'express';
import Stripe from 'stripe';
import dotenv from 'dotenv';
import cors from 'cors';
import bodyParser from 'body-parser';

dotenv.config();
const app = express();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2023-08-16' });

app.use(cors());
app.use(express.json());

// Example in-memory products catalog (replace with DB in production)
const PRODUCTS = [
  { id: 'prod_1', name: 'T‑Shirt', price_cents: 1999 },
  { id: 'prod_2', name: 'Mug', price_cents: 999 },
  { id: 'prod_3', name: 'Hat', price_cents: 1499 },
];

app.get('/products', (req, res) => {
  res.json(PRODUCTS);
});

// Create Checkout Session
app.post('/create-checkout-session', async (req, res) => {
  try {
    const { items, successUrl, cancelUrl } = req.body;
    // Validate items and amounts server-side!
    const line_items = items.map(item => {
      const prod = PRODUCTS.find(p => p.id === item.id);
      if (!prod) throw new Error('Invalid product ID: ' + item.id);
      return {
        price_data: {
          currency: 'usd',
          product_data: { name: prod.name },
          unit_amount: prod.price_cents,
        },
        quantity: item.quantity,
      };
    });

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items,
      success_url: successUrl || `${process.env.FRONTEND_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: cancelUrl || `${process.env.FRONTEND_URL}/cart`,
    });

    res.json({ sessionId: session.id });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: { message: err.message } });
  }
});

// Webhook endpoint for fulfilling orders (must use raw body)
app.post('/webhook', express.raw({ type: 'application/json' }), (req, res) => {
  const sig = req.headers['stripe-signature'];
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    if (event.type === 'checkout.session.completed') {
      const session = event.data.object;
      // Fulfill the purchase: create order in DB, send receipt, update inventory, etc.
      console.log('Payment succeeded for session:', session.id);
    }
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error:', err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
